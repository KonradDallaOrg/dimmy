# Dimmy — Design Specification

## Overview

Dimmy is a macOS menu bar voice dictation app. Push-to-talk with a global shortcut — the transcribed text is pasted into the active app. The prototype uses fake humorous text instead of real transcription to validate the full end-to-end flow.

**Target**: macOS 14+ (Sonoma)
**Stack**: Swift, SwiftUI, AppKit (NSStatusItem, NSPanel, NSEvent, CGEvent)
**Distribution**: Direct download (Accessibility API requires non-sandboxed app)

---

## Competitive Research Summary

Analyzed: Wispr Flow, SuperWhisper, Whisper Transcription/MacWhisper, macOS native Dictation.

### Key findings

| Area | Industry state | Dimmy's advantage |
|------|---------------|-------------------|
| Overlay UX | Polarizing (Wispr bar), chunky (SuperWhisper window), invisible (Apple cursor icon) | Minimal capsule pill — barely visible idle, expands on recording |
| PTT vs Toggle visual | No competitor distinguishes visually | Blue pulsing border (PTT) vs green border + stop button (toggle) |
| Onboarding | SuperWhisper: 6 steps + model confusion. Wispr: account required | 4 steps, no account, no model choice, interactive "try now" |
| Resource usage | Wispr: 800MB RAM | Native Swift, <50MB expected |
| Complexity | All competitors have steep learning curves | Single purpose: dictate and paste |

### Patterns adopted
- **From Wispr Flow**: Interactive onboarding with practice dictation, Fn-family shortcut
- **From SuperWhisper**: Mini recorder concept, clipboard restoration after paste
- **From macOS Dictation**: Privacy-first design, system-level visual indicators
- **From MacWhisper**: Progressive permission requests, push-to-talk as default mode

---

## Architecture

```
DimmyApp (SwiftUI App lifecycle, menu bar agent)
├── AppDelegate (NSApplicationDelegate)
│   ├── StatusBarController (NSStatusItem + popover)
│   └── PillWindowController (NSPanel floating overlay)
├── Managers/
│   ├── HotkeyManager (global key monitoring via NSEvent)
│   ├── AudioSimulator (fake recording states + timer)
│   └── TextInjector (clipboard + CGEvent Cmd+V paste)
├── State/
│   └── AppState (ObservableObject, single source of truth)
├── Views/
│   ├── MenuBarPopover (status, language, style, settings link)
│   ├── PillView (idle, recording-PTT, recording-toggle, completion)
│   ├── WaveformView (animated bars)
│   ├── OnboardingView (4-step wizard)
│   └── SettingsView (native macOS preferences)
└── Resources/
    └── FunnyTexts (array of humorous Italian/English strings)
```

### State management
Single `AppState: ObservableObject` with `@Published` properties:
- `isRecording: Bool`
- `recordingMode: RecordingMode` (.pushToTalk | .toggle)
- `isOnboardingComplete: Bool`
- `selectedLanguage: String`
- `selectedStyle: String`
- `theme: AppTheme` (.auto | .light | .dark)
- `shortcutKey: KeyCombo`
- `pillPosition: CGPoint`

### Dependencies
Zero external dependencies. Pure Apple frameworks:
- SwiftUI (UI)
- AppKit (NSStatusItem, NSPanel, NSEvent, NSPasteboard)
- CoreGraphics (CGEvent for simulated paste)
- Combine (reactive state)
- AVFoundation (microphone permission request only — no actual audio processing)

---

## Screens

### 1. Menu Bar Icon

**Implementation**: `NSStatusItem` with `NSStatusItem.variableLength`

| State | Icon | Behavior |
|-------|------|----------|
| Idle | `waveform.circle` (SF Symbol) | Left-click opens popover |
| Recording | `waveform.circle.fill` with tint | Pulses subtly |

**Popover contents**:
- Status line: "Ready" / "Recording..."
- Current language and style
- Shortcut reminder (e.g., "⌥Space to dictate")
- Divider
- "Settings..." (opens preferences)
- "Quit Dimmy"

### 2. Pill Overlay

**Implementation**: `NSPanel` subclass with:
- `styleMask: [.borderless, .nonactivatingPanel]`
- `level: .floating`
- `collectionBehavior: [.canJoinAllSpaces, .fullScreenAuxiliary]`
- `isMovableByWindowBackground: true`
- `backgroundColor: .clear`
- `hasShadow: true`

**Visual specs**:

| State | Size | Opacity | Border | Content |
|-------|------|---------|--------|---------|
| **Idle** | 120x36pt | 30% bg | None | Small waveform icon |
| **Idle (hover)** | 120x36pt | 80% bg | None | Language + "⌥Space" hint |
| **Recording PTT** | 200x44pt | 100% bg | 2pt blue, pulsing | Animated waveform (5 bars) |
| **Recording Toggle** | 220x44pt | 100% bg | 2pt green, steady | Animated waveform + ■ stop button |
| **Completion** | 160x44pt | 100% bg | 2pt green | ✓ checkmark scale-in |

**Background**: `NSVisualEffectView` with `.hudWindow` material for vibrancy.

**Positioning**: Default bottom-center of screen, 80pt above dock. Draggable — position persisted in UserDefaults.

**Animations**:
- Size transitions: `withAnimation(.spring(response: 0.3, dampingFraction: 0.8))`
- Waveform bars: Timer at 15fps, random heights 0.2–1.0, `RoundedRectangle` with smooth animation
- PTT border pulse: `Animation.easeInOut(duration: 0.8).repeatForever(autoreverses: true)`
- Completion checkmark: `.scale` transition from 0.5 to 1.0

### 3. Settings (Preferences Window)

**Implementation**: SwiftUI `Settings` scene (native macOS preferences).

**General tab**:
- Language: Dropdown (Italian, English, Spanish, French, German, Portuguese)
- Style: Dropdown (Default, Professional, Casual)
- Theme: Segmented control (Auto / Light / Dark)
- Launch at login: Toggle
- Show in Dock: Toggle

**Shortcut tab**:
- Current shortcut display
- "Change Shortcut" button → key capture overlay
- Mode preference: Segmented (Push-to-talk / Toggle)
- Double-tap interval slider (200–500ms)

**About tab**:
- App icon, version, "Made with irony"

### 4. Onboarding Wizard

**Implementation**: Separate `NSWindow`, modal, non-resizable, ~500x400pt.

**Step 1 — Welcome**:
- App icon (large)
- "Dimmy" title
- "Voice dictation that stays out of your way"
- Brief 2-line description
- "Get Started →" button

**Step 2 — Permissions**:
- Microphone section: explanation + "Grant Access" button → triggers `AVCaptureDevice.requestAccess`
- Accessibility section: explanation + "Open System Settings" button → opens `x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility`
- Checkmarks appear as each is granted
- "Continue →" enabled when both granted

**Step 3 — Shortcut & Modes**:
- Shows default ⌥Space
- "Hold ⌥Space — push-to-talk (release to paste)"
- "Double-tap ⌥Space — toggle mode (tap again or click ■ to stop)"
- "Try it now!" prompt
- Interactive: user tries the shortcut, pill appears, waveform plays

**Step 4 — Try It**:
- Embedded text field
- "Hold ⌥Space and say something"
- When user activates, fake recording plays, funny text gets pasted into the field
- "You're all set!" with animated checkmark
- "Start Using Dimmy" button → closes wizard, app is ready

---

## Text Injection Flow

1. Recording ends (key released for PTT, or stop pressed for toggle)
2. Pill shows completion animation (checkmark)
3. Random funny text selected from pool
4. Save current clipboard contents
5. Copy funny text to `NSPasteboard.general`
6. Create `CGEvent` for Cmd+V keydown/keyup, post to system
7. After 100ms delay, restore previous clipboard contents
8. Pill returns to idle state

### Funny text pool
```
"Stavo per dire qualcosa di brillante, ma Dimmy ha capito questo"
"Il mio gatto ha dettato questo messaggio"
"Dimmy funziona, il problema sei tu"
"Questo testo è stato generato da un criceto su una ruota"
"Ho detto cose importantissime ma Dimmy ha preferito questo"
"Se stai leggendo questo, la demo funziona"
"Dimmy ha trascritto i tuoi pensieri più profondi... ed erano questi"
"Il microfono funziona, il cervello è opzionale"
"Messaggio dettato con successo. Contenuto: irrilevante."
"La mia eloquenza è stata ridotta a questa singola riga"
```

---

## Global Hotkey Implementation

### Detection strategy
Monitor `flagsChanged` events for ⌥ (Option) key, then `keyDown` for Space.

**Push-to-talk**:
- ⌥ down + Space down → start recording
- Space up OR ⌥ up → stop recording, inject text

**Toggle (double-tap detection)**:
- Track timestamps of ⌥Space press/release pairs
- Two presses within 400ms → toggle mode ON
- Next ⌥Space press → toggle mode OFF, inject text
- Or click ■ stop button on pill → same

### Implementation
```swift
// Global monitor (works when app is not focused)
NSEvent.addGlobalMonitorForEvents(matching: [.flagsChanged, .keyDown, .keyUp]) { event in
    // Route to HotkeyManager
}

// Local monitor (works when app windows are focused)
NSEvent.addLocalMonitorForEvents(matching: [.flagsChanged, .keyDown, .keyUp]) { event in
    // Route to HotkeyManager
    return event
}
```

---

## Info.plist Configuration

```xml
LSUIElement: true              <!-- No dock icon by default -->
NSMicrophoneUsageDescription: "Dimmy needs microphone access to transcribe your voice."
```

---

## Dark/Light Mode

- Theme follows `NSApp.effectiveAppearance` when set to Auto
- Pill uses `NSVisualEffectView` which automatically adapts
- All colors use system semantic colors (`NSColor.controlBackgroundColor`, etc.)
- SF Symbols adapt automatically

---

## File Structure

```
Dimmy/
├── Dimmy.xcodeproj
├── Dimmy/
│   ├── DimmyApp.swift              (App entry point, menu bar setup)
│   ├── AppDelegate.swift           (NSApplicationDelegate, window controllers)
│   ├── Info.plist
│   ├── Assets.xcassets/
│   │   └── AppIcon.appiconset/
│   ├── State/
│   │   └── AppState.swift          (ObservableObject, app-wide state)
│   ├── Controllers/
│   │   ├── StatusBarController.swift   (NSStatusItem management)
│   │   └── PillWindowController.swift  (NSPanel setup and management)
│   ├── Managers/
│   │   ├── HotkeyManager.swift     (Global event monitoring)
│   │   ├── AudioSimulator.swift    (Fake recording timer + states)
│   │   └── TextInjector.swift      (Clipboard + CGEvent paste)
│   ├── Views/
│   │   ├── MenuBarPopover.swift    (Popover content)
│   │   ├── PillView.swift          (All pill states)
│   │   ├── WaveformView.swift      (Animated bars)
│   │   ├── Onboarding/
│   │   │   ├── OnboardingContainerView.swift
│   │   │   ├── WelcomeStepView.swift
│   │   │   ├── PermissionsStepView.swift
│   │   │   ├── ShortcutStepView.swift
│   │   │   └── TryItStepView.swift
│   │   └── Settings/
│   │       ├── GeneralSettingsView.swift
│   │       ├── ShortcutSettingsView.swift
│   │       └── AboutSettingsView.swift
│   └── Utilities/
│       └── FunnyTexts.swift        (Random text pool)
└── README.md                       (not created unless requested)
```

---

## Scope boundaries (prototype)

**In scope**:
- Full UI navigation (menu bar → popover, pill overlay, settings, onboarding)
- Simulated recording with waveform animation
- Fake text pasted into active app via clipboard + Cmd+V
- Global hotkey detection (⌥Space)
- Push-to-talk and toggle modes with visual distinction
- Dark/light mode
- Draggable pill with position persistence
- Onboarding wizard with interactive "try it" step

**Out of scope (future)**:
- Real audio recording and transcription
- AI post-processing
- Custom vocabulary
- Context-aware formatting
- History/transcript log
- Multiple languages (UI is English/Italian, but no actual language processing)
