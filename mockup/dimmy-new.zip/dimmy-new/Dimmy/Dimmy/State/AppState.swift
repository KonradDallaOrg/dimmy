import SwiftUI
import Combine

enum RecordingMode: String, CaseIterable {
    case pushToTalk = "Push-to-Talk"
    case toggle = "Toggle"
}

enum AppTheme: String, CaseIterable {
    case auto = "Auto"
    case light = "Light"
    case dark = "Dark"
}

enum RecordingState: Equatable {
    case idle
    case recording(RecordingMode)
    case completing
}

/// Represents a modifier-key-only shortcut (e.g., ⌃⌥ or Fn)
struct ModifierShortcut: Equatable {
    var fn: Bool
    var control: Bool
    var option: Bool
    var command: Bool
    var shift: Bool

    var displayString: String {
        displayParts.joined(separator: "")
    }

    var displayParts: [String] {
        var parts: [String] = []
        if fn { parts.append("fn") }
        if control { parts.append("⌃") }
        if option { parts.append("⌥") }
        if shift { parts.append("⇧") }
        if command { parts.append("⌘") }
        return parts
    }

    var isFnOnly: Bool {
        fn && !control && !option && !command && !shift
    }

    func matches(flags: NSEvent.ModifierFlags) -> Bool {
        let f = flags.intersection(.deviceIndependentFlagsMask)
        return f.contains(.function) == fn
            && f.contains(.control) == control
            && f.contains(.option) == option
            && f.contains(.command) == command
            && f.contains(.shift) == shift
    }

    /// Fn alone is valid; otherwise need 2+ modifiers
    var isValid: Bool {
        if fn && !control && !option && !command && !shift { return true }
        let count = [control, option, command, shift].filter { $0 }.count
        return count >= 2
    }

    static let fnOnly = ModifierShortcut(fn: true, control: false, option: false, command: false, shift: false)
    static let controlOption = ModifierShortcut(fn: false, control: true, option: true, command: false, shift: false)
    static let `default` = controlOption

    // Persistence
    var encoded: Int {
        var val = 0
        if control { val |= 1 }
        if option { val |= 2 }
        if command { val |= 4 }
        if shift { val |= 8 }
        if fn { val |= 16 }
        return val
    }

    init(fn: Bool = false, control: Bool, option: Bool, command: Bool, shift: Bool) {
        self.fn = fn
        self.control = control
        self.option = option
        self.command = command
        self.shift = shift
    }

    init(encoded: Int) {
        self.control = encoded & 1 != 0
        self.option = encoded & 2 != 0
        self.command = encoded & 4 != 0
        self.shift = encoded & 8 != 0
        self.fn = encoded & 16 != 0
    }
}

@MainActor
final class AppState: ObservableObject {
    static let shared = AppState()

    @Published var recordingState: RecordingState = .idle
    @Published var preferredMode: RecordingMode = .pushToTalk
    @Published var isOnboardingComplete: Bool {
        didSet { UserDefaults.standard.set(isOnboardingComplete, forKey: "isOnboardingComplete") }
    }
    @Published var selectedLanguage: String = "Italiano"
    @Published var selectedStyle: String = "Default"
    @Published var theme: AppTheme = .auto
    @Published var shortcut: ModifierShortcut {
        didSet { UserDefaults.standard.set(shortcut.encoded, forKey: "shortcutEncoded") }
    }
    @Published var pillPosition: CGPoint? {
        didSet {
            if let pos = pillPosition {
                UserDefaults.standard.set(pos.x, forKey: "pillX")
                UserDefaults.standard.set(pos.y, forKey: "pillY")
            }
        }
    }
    @Published var waveformLevels: [CGFloat] = Array(repeating: 0.2, count: 7)
    @Published var micPermissionGranted: Bool = false
    @Published var accessibilityPermissionGranted: Bool = false
    @Published var showPillIntro: Bool = false

    var isRecording: Bool {
        if case .recording = recordingState { return true }
        return false
    }

    let languages = ["Italiano", "English", "Español", "Français", "Deutsch", "Português"]
    let styles = ["Default", "Professional", "Casual"]

    private init() {
        self.isOnboardingComplete = UserDefaults.standard.bool(forKey: "isOnboardingComplete")
        let savedX = UserDefaults.standard.double(forKey: "pillX")
        let savedY = UserDefaults.standard.double(forKey: "pillY")
        if savedX != 0 || savedY != 0 {
            self.pillPosition = CGPoint(x: savedX, y: savedY)
        }
        let savedShortcut = UserDefaults.standard.integer(forKey: "shortcutEncoded")
        if savedShortcut != 0 {
            self.shortcut = ModifierShortcut(encoded: savedShortcut)
        } else {
            self.shortcut = .default
        }
    }
}
