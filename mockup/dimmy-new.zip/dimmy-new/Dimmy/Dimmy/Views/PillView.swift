import SwiftUI

struct PillView: View {
    @ObservedObject var appState: AppState
    @State private var isHovering = false
    @State private var borderPhase: Double = 0
    @State private var showCheckmark = false
    @State private var introPhase: Double = 0

    private let pillHeight: CGFloat = 36

    var body: some View {
        ZStack {
            switch appState.recordingState {
            case .idle:
                idleView
            case .recording(let mode):
                recordingView(mode: mode)
            case .completing:
                completionView
            }
        }
        .contextMenu {
            Button("Settings...") {
                AppDelegate.shared?.openSettings()
            }
            Divider()
            Button("Quit Dimmy") {
                NSApplication.shared.terminate(nil)
            }
        }
        .onChange(of: appState.showPillIntro) { _, show in
            if show {
                introPhase = 0
                withAnimation(.linear(duration: 1.5).repeatForever(autoreverses: false)) {
                    introPhase = 360
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                    withAnimation(.easeOut(duration: 0.5)) {
                        appState.showPillIntro = false
                        introPhase = 0
                    }
                }
            }
        }
    }

    // MARK: - Idle State

    private var idleView: some View {
        HStack(spacing: 10) {
            Image(systemName: "waveform")
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(.secondary)
            if isHovering {
                Text(appState.selectedLanguage)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(.primary)
                Text(appState.shortcut.displayString)
                    .font(.system(size: 11, weight: .medium, design: .monospaced))
                    .foregroundColor(.secondary)
            }
        }
        .frame(height: pillHeight)
        .padding(.horizontal, isHovering ? 16 : 14)
        .background(
            Capsule()
                .fill(.ultraThinMaterial)
                .opacity(isHovering ? 0.95 : 0.5)
        )
        .overlay(
            Capsule()
                .stroke(
                    appState.showPillIntro ? rainbowGradient(phase: introPhase) : rainbowGradient(phase: 0),
                    lineWidth: appState.showPillIntro ? 2 : 0.5
                )
                .opacity(appState.showPillIntro ? 1.0 : 0.12)
        )
        .shadow(color: appState.showPillIntro ? glowColor(phase: introPhase, offset: 0.0) : .clear, radius: 12)
        .shadow(color: appState.showPillIntro ? glowColor(phase: introPhase, offset: 0.3) : .clear, radius: 8)
        .shadow(color: appState.showPillIntro ? glowColor(phase: introPhase, offset: 0.6) : .clear, radius: 4)
        .onHover { hovering in
            withAnimation(.easeInOut(duration: 0.2)) {
                isHovering = hovering
            }
        }
    }

    // MARK: - Recording State

    private func recordingView(mode: RecordingMode) -> some View {
        HStack(spacing: 12) {
            WaveformView(levels: appState.waveformLevels)

            if mode == .toggle {
                Button(action: {
                    HotkeyManager.shared.stopToggleRecording()
                }) {
                    RoundedRectangle(cornerRadius: 2.5)
                        .fill(Color.white.opacity(0.9))
                        .frame(width: 12, height: 12)
                }
                .buttonStyle(.plain)
                .contentShape(Rectangle())
            }
        }
        .frame(height: pillHeight)
        .padding(.horizontal, 18)
        .background(
            Capsule()
                .fill(.ultraThickMaterial)
        )
        .overlay(
            Capsule()
                .stroke(rainbowGradient(phase: borderPhase), lineWidth: 2)
        )
        .shadow(color: glowColor(phase: borderPhase, offset: 0.0), radius: 12)
        .shadow(color: glowColor(phase: borderPhase, offset: 0.3), radius: 8)
        .shadow(color: glowColor(phase: borderPhase, offset: 0.6), radius: 4)
        .onAppear {
            borderPhase = 0
            withAnimation(.linear(duration: 2.5).repeatForever(autoreverses: false)) {
                borderPhase = 360
            }
        }
        .onDisappear {
            borderPhase = 0
        }
    }

    // MARK: - Completion State

    private var completionView: some View {
        Image(systemName: "checkmark")
            .font(.system(size: 16, weight: .bold))
            .foregroundColor(.green)
            .scaleEffect(showCheckmark ? 1.0 : 0.3)
            .opacity(showCheckmark ? 1.0 : 0.0)
            .frame(height: pillHeight)
            .padding(.horizontal, 16)
            .background(
                Capsule()
                    .fill(.ultraThickMaterial)
            )
            .overlay(
                Capsule()
                    .stroke(Color.green.opacity(0.4), lineWidth: 1.5)
            )
            .shadow(color: .green.opacity(0.4), radius: 10)
            .onAppear {
                withAnimation(.spring(response: 0.25, dampingFraction: 0.6)) {
                    showCheckmark = true
                }
            }
            .onDisappear {
                showCheckmark = false
            }
    }

    // MARK: - Rainbow helpers

    private func rainbowGradient(phase: Double) -> AngularGradient {
        AngularGradient(
            gradient: Gradient(colors: rainbowColors),
            center: .center,
            angle: .degrees(phase)
        )
    }

    /// Rotating glow color based on phase
    private func glowColor(phase: Double, offset: Double) -> Color {
        let hue = ((phase / 360.0) + offset).truncatingRemainder(dividingBy: 1.0)
        return Color(hue: hue, saturation: 0.6, brightness: 1.0).opacity(0.4)
    }

    private var rainbowColors: [Color] {
        [
            Color(hue: 0.0, saturation: 0.7, brightness: 1.0),
            Color(hue: 0.08, saturation: 0.8, brightness: 1.0),
            Color(hue: 0.15, saturation: 0.7, brightness: 1.0),
            Color(hue: 0.35, saturation: 0.7, brightness: 0.95),
            Color(hue: 0.52, saturation: 0.6, brightness: 1.0),
            Color(hue: 0.62, saturation: 0.7, brightness: 1.0),
            Color(hue: 0.75, saturation: 0.6, brightness: 1.0),
            Color(hue: 0.85, saturation: 0.6, brightness: 1.0),
            Color(hue: 0.95, saturation: 0.7, brightness: 1.0),
        ]
    }
}

extension RecordingState {
    var animationId: Int {
        switch self {
        case .idle: return 0
        case .recording(.pushToTalk): return 1
        case .recording(.toggle): return 2
        case .completing: return 3
        }
    }
}
