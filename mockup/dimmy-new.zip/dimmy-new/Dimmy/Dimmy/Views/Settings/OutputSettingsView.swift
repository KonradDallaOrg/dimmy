import SwiftUI

struct OutputSettingsView: View {
    @ObservedObject var appState: AppState

    var body: some View {
        Form {
            Section("Text Processing") {
                Picker("Style", selection: $appState.selectedStyle) {
                    ForEach(appState.styles, id: \.self) { style in
                        Text(style).tag(style)
                    }
                }

                Text("How your dictation is formatted before pasting")
                    .font(.system(size: 11))
                    .foregroundColor(.secondary)
            }

            Section("Post-Processing") {
                Toggle("Remove filler words", isOn: .constant(true))
                Toggle("Auto-punctuation", isOn: .constant(true))
                Toggle("Auto-capitalization", isOn: .constant(true))
            }

            Section("Clipboard") {
                Toggle("Restore clipboard after paste", isOn: .constant(true))

                Text("After pasting, the previous clipboard content is restored")
                    .font(.system(size: 11))
                    .foregroundColor(.secondary)
            }

            Section("Paste Method") {
                Picker("Method", selection: .constant(0)) {
                    Text("Simulate ⌘V").tag(0)
                    Text("Simulate keystrokes").tag(1)
                }

                Text("Use keystrokes if some apps don't accept paste")
                    .font(.system(size: 11))
                    .foregroundColor(.secondary)
            }
        }
        .formStyle(.grouped)
    }
}
