import SwiftUI

struct GeneralSettingsView: View {
    @ObservedObject var appState: AppState

    var body: some View {
        Form {
            Section("Transcription") {
                Picker("Language", selection: $appState.selectedLanguage) {
                    ForEach(appState.languages, id: \.self) { lang in
                        Text(lang).tag(lang)
                    }
                }

                Picker("Style", selection: $appState.selectedStyle) {
                    ForEach(appState.styles, id: \.self) { style in
                        Text(style).tag(style)
                    }
                }

                Text("Style adjusts the tone of the transcribed text")
                    .font(.system(size: 11))
                    .foregroundColor(.secondary)
            }

            Section("Appearance") {
                Picker("Theme", selection: $appState.theme) {
                    ForEach(AppTheme.allCases, id: \.self) { theme in
                        Text(theme.rawValue).tag(theme)
                    }
                }
                .pickerStyle(.segmented)
            }

            Section("System") {
                Toggle("Launch at login", isOn: .constant(false))
                Toggle("Show in Dock", isOn: .constant(false))
            }
        }
        .formStyle(.grouped)
    }
}
