import SwiftUI

struct OverlaySettingsView: View {
    @ObservedObject var appState: AppState

    var body: some View {
        Form {
            Section("Pill Overlay") {
                Toggle("Show overlay", isOn: .constant(true))

                Picker("Default position", selection: .constant(0)) {
                    Text("Top Right").tag(0)
                    Text("Top Left").tag(1)
                    Text("Bottom Right").tag(2)
                    Text("Bottom Left").tag(3)
                    Text("Bottom Center").tag(4)
                }

                Button("Reset Position") {
                    UserDefaults.standard.removeObject(forKey: "pillX")
                    UserDefaults.standard.removeObject(forKey: "pillY")
                    appState.pillPosition = nil
                }

                Text("You can always drag the pill to reposition it")
                    .font(.system(size: 11))
                    .foregroundColor(.secondary)
            }

            Section("Idle State") {
                Picker("Idle opacity", selection: .constant(1)) {
                    Text("Nearly invisible").tag(0)
                    Text("Subtle").tag(1)
                    Text("Visible").tag(2)
                }
            }

            Section("Recording Animation") {
                Picker("Border style", selection: .constant(0)) {
                    Text("Rainbow").tag(0)
                    Text("Blue pulse").tag(1)
                    Text("Green").tag(2)
                    Text("None").tag(3)
                }

                Picker("Waveform style", selection: .constant(0)) {
                    Text("Bars").tag(0)
                    Text("Line").tag(1)
                    Text("Dots").tag(2)
                }
            }
        }
        .formStyle(.grouped)
    }
}
