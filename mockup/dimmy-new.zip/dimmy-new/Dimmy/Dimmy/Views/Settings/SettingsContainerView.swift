import SwiftUI

enum SettingsTab: String, CaseIterable, Identifiable {
    case general = "General"
    case shortcut = "Shortcut"
    case output = "Output"
    case pill = "Overlay"
    case permissions = "Permissions"
    case about = "About"

    var id: String { rawValue }

    var icon: String {
        switch self {
        case .general: return "gear"
        case .shortcut: return "command.square"
        case .output: return "doc.text"
        case .pill: return "capsule"
        case .permissions: return "lock.shield"
        case .about: return "info.circle"
        }
    }
}

struct SettingsContainerView: View {
    @ObservedObject var appState: AppState
    @State private var selectedTab: SettingsTab = .general

    var body: some View {
        NavigationSplitView {
            List(SettingsTab.allCases, selection: $selectedTab) { tab in
                Label(tab.rawValue, systemImage: tab.icon)
                    .tag(tab)
            }
            .listStyle(.sidebar)
            .navigationSplitViewColumnWidth(min: 160, ideal: 180, max: 200)
        } detail: {
            ScrollView {
                detailView
                    .frame(maxWidth: 480)
                    .padding(.vertical, 8)
            }
            .frame(maxWidth: .infinity)
        }
    }

    @ViewBuilder
    private var detailView: some View {
        switch selectedTab {
        case .general:
            GeneralSettingsView(appState: appState)
        case .shortcut:
            ShortcutSettingsView(appState: appState)
        case .output:
            OutputSettingsView(appState: appState)
        case .pill:
            OverlaySettingsView(appState: appState)
        case .permissions:
            PermissionsSettingsView()
        case .about:
            AboutSettingsView()
        }
    }
}
