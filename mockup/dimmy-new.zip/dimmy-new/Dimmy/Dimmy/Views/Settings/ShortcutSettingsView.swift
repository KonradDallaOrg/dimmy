import SwiftUI

struct ShortcutSettingsView: View {
    @ObservedObject var appState: AppState
    @State private var isRecording = false
    @State private var monitor: Any?

    var body: some View {
        Form {
            Section("Dictation Shortcut") {
                HStack {
                    Text("Shortcut")
                    Spacer()

                    if isRecording {
                        Text("Press keys...")
                            .font(.system(size: 13))
                            .foregroundColor(.orange)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(
                                RoundedRectangle(cornerRadius: 6)
                                    .fill(Color.orange.opacity(0.1))
                            )
                    } else {
                        Button(action: { startRecording() }) {
                            HStack(spacing: 4) {
                                ForEach(appState.shortcut.displayParts, id: \.self) { part in
                                    Text(part)
                                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                                        .padding(.horizontal, 8)
                                        .padding(.vertical, 4)
                                        .background(
                                            RoundedRectangle(cornerRadius: 5)
                                                .fill(Color(nsColor: .controlBackgroundColor))
                                        )
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 5)
                                                .stroke(Color.primary.opacity(0.15), lineWidth: 1)
                                        )
                                }
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }

                Text("Hold the shortcut to start dictating, release to paste")
                    .font(.system(size: 11))
                    .foregroundColor(.secondary)
            }

            Section("Mode") {
                Picker("Default mode", selection: $appState.preferredMode) {
                    ForEach(RecordingMode.allCases, id: \.self) { mode in
                        Text(mode.rawValue).tag(mode)
                    }
                }
                .pickerStyle(.segmented)

                VStack(alignment: .leading, spacing: 6) {
                    Label("Push-to-talk: hold shortcut, release to paste", systemImage: "hand.raised")
                    Label("Toggle: double-tap to start, tap again to stop", systemImage: "arrow.triangle.2.circlepath")
                }
                .font(.system(size: 11))
                .foregroundColor(.secondary)
            }
        }
        .formStyle(.grouped)
        .onDisappear {
            stopRecording()
        }
    }

    private func startRecording() {
        isRecording = true
        monitor = NSEvent.addLocalMonitorForEvents(matching: .flagsChanged) { event in
            let flags = event.modifierFlags.intersection(.deviceIndependentFlagsMask)
            let candidate = ModifierShortcut(
                fn: flags.contains(.function),
                control: flags.contains(.control),
                option: flags.contains(.option),
                command: flags.contains(.command),
                shift: flags.contains(.shift)
            )
            if candidate.isValid {
                Task { @MainActor in
                    self.appState.shortcut = candidate
                    self.stopRecording()
                }
            }
            return event
        }
    }

    private func stopRecording() {
        isRecording = false
        if let m = monitor {
            NSEvent.removeMonitor(m)
            monitor = nil
        }
    }
}
