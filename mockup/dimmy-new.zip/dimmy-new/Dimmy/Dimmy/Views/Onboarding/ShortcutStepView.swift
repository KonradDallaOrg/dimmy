import SwiftUI

struct ShortcutStepView: View {
    @ObservedObject var appState: AppState
    let onContinue: () -> Void
    @State private var isRecording = false
    @State private var pendingShortcut: ModifierShortcut?
    @State private var monitor: Any?

    private var activeShortcut: ModifierShortcut {
        pendingShortcut ?? appState.shortcut
    }

    var body: some View {
        VStack(spacing: 28) {
            Spacer()

            Text("Your Shortcut")
                .font(.system(size: 28, weight: .bold))

            Text("Hold to dictate, release to paste")
                .font(.system(size: 14))
                .foregroundColor(.secondary)

            // The recorder — click to change
            Button(action: {
                if isRecording {
                    stopRecording()
                } else {
                    startRecording()
                }
            }) {
                VStack(spacing: 12) {
                    if isRecording {
                        Text("Press your shortcut...")
                            .font(.system(size: 15, weight: .medium))
                            .foregroundColor(.orange)
                            .frame(height: 50)
                    } else {
                        HStack(spacing: 10) {
                            ForEach(Array(activeShortcut.displayParts.enumerated()), id: \.offset) { index, part in
                                if index > 0 {
                                    Text("+")
                                        .font(.system(size: 22, weight: .light))
                                        .foregroundColor(.secondary)
                                }
                                Text(part)
                                    .font(.system(size: 24, weight: .semibold, design: .rounded))
                                    .padding(.horizontal, 18)
                                    .padding(.vertical, 12)
                                    .background(
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(Color(nsColor: .controlBackgroundColor))
                                            .shadow(color: .black.opacity(0.2), radius: 2, y: 1)
                                    )
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 10)
                                            .stroke(Color.primary.opacity(0.15), lineWidth: 1)
                                    )
                            }
                        }
                        .frame(height: 50)
                    }

                    Text(isRecording ? "Hold 2+ modifier keys together" : "Click to change")
                        .font(.system(size: 12))
                        .foregroundColor(Color(nsColor: .tertiaryLabelColor))
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 20)
                .background(
                    RoundedRectangle(cornerRadius: 14)
                        .fill(isRecording
                              ? Color.orange.opacity(0.08)
                              : Color(nsColor: .controlBackgroundColor).opacity(0.5))
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 14)
                        .stroke(isRecording ? Color.orange.opacity(0.4) : Color.clear, lineWidth: 1.5)
                )
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 10)

            Spacer()

            Button(action: {
                if let pending = pendingShortcut {
                    appState.shortcut = pending
                }
                onContinue()
            }) {
                Text("Continue")
                    .font(.system(size: 15, weight: .semibold))
                    .frame(maxWidth: 220)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)

            Spacer().frame(height: 20)
        }
        .padding(.horizontal, 40)
        .onDisappear {
            stopRecording()
        }
    }

    private func startRecording() {
        isRecording = true
        monitor = NSEvent.addLocalMonitorForEvents(matching: .flagsChanged) { event in
            let flags = event.modifierFlags.intersection(.deviceIndependentFlagsMask)
            let candidate = ModifierShortcut(
                fn: flags.contains(.function),
                control: flags.contains(.control),
                option: flags.contains(.option),
                command: flags.contains(.command),
                shift: flags.contains(.shift)
            )
            if candidate.isValid {
                Task { @MainActor in
                    withAnimation(.easeInOut(duration: 0.2)) {
                        self.pendingShortcut = candidate
                    }
                    self.stopRecording()
                }
            }
            return event
        }
    }

    private func stopRecording() {
        isRecording = false
        if let m = monitor {
            NSEvent.removeMonitor(m)
            monitor = nil
        }
    }
}

struct KeyCapView: View {
    let text: String

    var body: some View {
        Text(text)
            .font(.system(size: 18, weight: .semibold, design: .rounded))
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color(nsColor: .controlBackgroundColor))
                    .shadow(color: .black.opacity(0.15), radius: 1, y: 1)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color.primary.opacity(0.15), lineWidth: 1)
            )
    }
}
