import SwiftUI

struct WaveformView: View {
    let levels: [CGFloat]
    let barCount: Int

    init(levels: [CGFloat], barCount: Int = 7) {
        self.levels = levels
        self.barCount = barCount
    }

    var body: some View {
        HStack(alignment: .center, spacing: 3) {
            ForEach(0..<barCount, id: \.self) { index in
                RoundedRectangle(cornerRadius: 1.5)
                    .fill(Color.white.opacity(0.9))
                    .frame(width: 3, height: barHeight(for: index))
            }
        }
        .frame(height: 18) // Fixed height — bars animate WITHIN this
        .animation(.easeOut(duration: 0.2), value: levels)
    }

    private func barHeight(for index: Int) -> CGFloat {
        let level = index < levels.count ? levels[index] : 0.2
        let minHeight: CGFloat = 3
        let maxHeight: CGFloat = 16
        return minHeight + (maxHeight - minHeight) * level
    }
}

struct WaveformIconView: View {
    var body: some View {
        HStack(spacing: 3) {
            ForEach(0..<3, id: \.self) { index in
                RoundedRectangle(cornerRadius: 1.5)
                    .fill(Color.secondary)
                    .frame(width: 3, height: [8, 14, 8][index])
            }
        }
    }
}
