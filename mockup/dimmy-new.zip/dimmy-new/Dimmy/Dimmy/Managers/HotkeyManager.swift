import AppKit
import Carbon

@MainActor
final class HotkeyManager {
    static let shared = HotkeyManager()

    private var globalFlagsMonitor: Any?
    private var localFlagsMonitor: Any?

    // Track modifier state
    private var controlOptionDown = false

    // Double-tap detection for toggle mode
    private var lastReleaseTime: Date?
    private var lastPressTime: Date?
    private let doubleTapInterval: TimeInterval = 0.4

    // Minimum hold to avoid accidental triggers
    private let minimumHoldDuration: TimeInterval = 0.15

    private var appState: AppState?
    private var audioSimulator: AudioSimulator?

    private init() {}

    func start(appState: AppState, audioSimulator: AudioSimulator) {
        self.appState = appState
        self.audioSimulator = audioSimulator

        globalFlagsMonitor = NSEvent.addGlobalMonitorForEvents(matching: .flagsChanged) { [weak self] event in
            Task { @MainActor in
                self?.handleFlagsChanged(event)
            }
        }

        localFlagsMonitor = NSEvent.addLocalMonitorForEvents(matching: .flagsChanged) { [weak self] event in
            Task { @MainActor in
                self?.handleFlagsChanged(event)
            }
            return event
        }
    }

    func stop() {
        if let m = globalFlagsMonitor { NSEvent.removeMonitor(m) }
        if let m = localFlagsMonitor { NSEvent.removeMonitor(m) }
        globalFlagsMonitor = nil
        localFlagsMonitor = nil
    }

    private func handleFlagsChanged(_ event: NSEvent) {
        let flags = event.modifierFlags.intersection(.deviceIndependentFlagsMask)
        // Check that ONLY control and option are pressed (no other modifiers)
        guard let appState else { return }
        let onlyControlOption = appState.shortcut.matches(flags: flags)

        if onlyControlOption && !controlOptionDown {
            // ⌃⌥ just pressed
            controlOptionDown = true
            lastPressTime = Date()
            handlePress()
        } else if !onlyControlOption && controlOptionDown {
            // ⌃⌥ just released
            controlOptionDown = false
            handleRelease()
        }
    }

    private func handlePress() {
        guard let appState else { return }

        let now = Date()

        // If in toggle recording, stop it
        if case .recording(.toggle) = appState.recordingState {
            stopRecordingIfNeeded()
            lastReleaseTime = nil
            return
        }

        // Check for double-tap: if last release was recent, this is a toggle activation
        if let lastRelease = lastReleaseTime, now.timeIntervalSince(lastRelease) < doubleTapInterval {
            lastReleaseTime = nil
            startRecording(mode: .toggle)
            return
        }

        // Start push-to-talk
        startRecording(mode: .pushToTalk)
    }

    private func handleRelease() {
        guard let appState else { return }

        // Only stop push-to-talk on release (toggle stays active)
        if case .recording(.pushToTalk) = appState.recordingState {
            // Check minimum hold duration to avoid accidental triggers
            if let pressTime = lastPressTime, Date().timeIntervalSince(pressTime) < minimumHoldDuration {
                // Too short — treat as potential double-tap, don't paste yet
                stopRecordingWithoutInjection()
                lastReleaseTime = Date()
                return
            }
            stopRecordingIfNeeded()
        }

        lastReleaseTime = Date()
    }

    private func startRecording(mode: RecordingMode) {
        guard let appState, let audioSimulator else { return }
        guard case .idle = appState.recordingState else { return }

        appState.recordingState = .recording(mode)
        audioSimulator.startRecording(appState: appState)
    }

    private func stopRecordingIfNeeded() {
        guard let appState, let audioSimulator else { return }
        guard appState.isRecording else { return }

        audioSimulator.stopRecording(appState: appState)
    }

    private func stopRecordingWithoutInjection() {
        guard let appState else { return }
        guard appState.isRecording else { return }

        AudioSimulator.shared.cancelRecording(appState: appState)
    }

    func stopToggleRecording() {
        stopRecordingIfNeeded()
    }
}
