import AppKit
import SwiftUI
import Combine

@MainActor
final class PillWindowController {
    private var panel: NSPanel?
    private var appState: AppState
    private var cancellables = Set<AnyCancellable>()

    // Extra padding around the pill so glow/shadow isn't clipped
    static let glowPadding: CGFloat = 20

    init(appState: AppState) {
        self.appState = appState
        setupPanel()
        observeState()
    }

    private func setupPanel() {
        let pillView = PillView(appState: appState)
            .padding(Self.glowPadding) // Padding so glow isn't clipped

        let hostingView = NSHostingView(rootView: pillView)

        let panelWidth: CGFloat = 280 + Self.glowPadding * 2
        let panelHeight: CGFloat = 56 + Self.glowPadding * 2

        let panel = NSPanel(
            contentRect: NSRect(x: 0, y: 0, width: panelWidth, height: panelHeight),
            styleMask: [.borderless, .nonactivatingPanel],
            backing: .buffered,
            defer: false
        )

        panel.level = .floating
        panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
        panel.isMovableByWindowBackground = true
        panel.backgroundColor = .clear
        panel.isOpaque = false
        panel.hasShadow = false // We handle shadow ourselves via glow
        panel.hidesOnDeactivate = false
        panel.titleVisibility = .hidden
        panel.titlebarAppearsTransparent = true
        panel.contentView = hostingView

        if let screen = NSScreen.main {
            let screenFrame = screen.visibleFrame
            let x: CGFloat
            let y: CGFloat

            if let savedPosition = appState.pillPosition {
                x = savedPosition.x
                y = savedPosition.y
            } else {
                x = screenFrame.maxX - panelWidth - 100
                y = screenFrame.maxY - panelHeight - 100
            }

            panel.setFrame(NSRect(x: x, y: y, width: panelWidth, height: panelHeight), display: true)
        }

        self.panel = panel
    }

    func show() {
        panel?.orderFront(nil)
    }

    func hide() {
        panel?.orderOut(nil)
    }

    private func observeState() {
        NotificationCenter.default.publisher(for: NSWindow.didMoveNotification, object: panel)
            .compactMap { ($0.object as? NSWindow)?.frame.origin }
            .sink { [weak self] origin in
                self?.appState.pillPosition = origin
            }
            .store(in: &cancellables)

        appState.$isOnboardingComplete
            .receive(on: DispatchQueue.main)
            .sink { [weak self] complete in
                if complete {
                    self?.show()
                }
            }
            .store(in: &cancellables)

        // Show pill early when intro glow is triggered (during onboarding Try It step)
        appState.$showPillIntro
            .receive(on: DispatchQueue.main)
            .sink { [weak self] show in
                if show {
                    self?.show()
                }
            }
            .store(in: &cancellables)
    }
}
